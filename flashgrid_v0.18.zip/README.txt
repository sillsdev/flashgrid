To install on windows run CopyFilesToAddons.bat

This will copy the whole flashgrid folder to the add ons folder
(which can also be done manually)

The add ons folder is located at:
%appdata%\Anki2\addons21\

Where %appdata% is the users application data folder within their profile