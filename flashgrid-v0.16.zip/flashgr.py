"""
Anki addon that lets you drill using a grid of multiple cards.
"""

from flashgrid import reviewerMonkey  # which will in turn import main
from flashgrid import flashfork
from flashgrid import restrictCards

