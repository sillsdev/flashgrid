Here is some info on getting started developing this addon, or Anki in general.

Much of it--but not all--is focused on setting up a Linux VM as the dev/test machine, although with a few manual steps dev can be done on Windows too.

https://github.com/sillsdev/flashgrab/wiki/How-to-run-and-debug-Anki-in-a-Linux-virtual-machine-or-in-Windows

Note that that readme is from the sister project (FlashGrab), but it applies equally to this project.