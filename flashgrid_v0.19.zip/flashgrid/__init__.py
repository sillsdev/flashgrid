from flashgrid import reviewerMonkey  # which will in turn import main
from flashgrid import restrictCards
