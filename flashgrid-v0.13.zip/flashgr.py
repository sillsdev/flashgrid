"""
Anki addon that lets you drill using a grid of multiple cards.
"""

from flashgrid import reviewerMonkey

#from anki import reviewerMonkey #, main


