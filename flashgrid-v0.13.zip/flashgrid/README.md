FlashGrid
==========

An Anki addon for drilling flashcards by selecting the correct card from a grid layout of several cards.
See the Anki website's list of provided addons.
